import os
import random
import numpy as np
from PIL import Image
import cv2
import json
import time

def recognition(input_data:np.ndarray) -> np.ndarray:
    # 処理結果画像(1chグレースケール画像)
    result_img = np.zeros(input_data.shape, np.uint8)
    
    # ここに処理を書く


    # 処理結果の画像を返す
    return result_img


FILEPATH_INPUT_DATA_JSON = r"valid/dataset.json"
ANSWER_VALUE_TYPE = "image-1ch"
MULTI_DATA = False
INPUT_DATA_TYPE = "image-1ch"

def read_dataset(path_json, answer_value_type=int, multi_data=False, input_data_type="image-3ch"):
    base_dir = os.path.dirname(os.path.abspath(__file__))
    json_open = open(os.path.join(base_dir, path_json), 'r')
    dataset = json.load(json_open)

    filename_list = []
    input_data_list = [] #入力データ
    correct_list = [] #正解値
    num_problem = 0

    for item in dataset["data"]:
        try:
            # 正解値
            if type(answer_value_type) is str:
                if answer_value_type == "image-1ch":
                    # 画像の読み込み(グレースケール)
                    correct_list.append(np.array(Image.open(os.path.join(base_dir, os.path.dirname(path_json), item["gt"])).convert("L")))
                else:
                    raise(ValueError(f"answer_value_typeの指定({answer_value_type})が不正です。"))
            else:
                correct_list.append(answer_value_type(item["gt"]))

            # 入力データ
            data = []
            filename = []
            if multi_data:
                for path in item["path"]:
                    # 画像読み込み
                    filename.append(path)
                    image = Image.open(os.path.join(base_dir, os.path.dirname(path_json), path))
                    if input_data_type == "image-1ch":
                        image = image.convert("L")
                    data.append(np.array(image))
            else:
                # 画像読み込み
                filename = item["path"]
                image = Image.open(os.path.join(base_dir, os.path.dirname(path_json), item["path"]))
                if input_data_type == "image-1ch":
                    image = image.convert("L")
                data = np.array(image)

            # 複数データの場合にひとまとめの行列にする
            if multi_data:
                input_data_list.append(np.array(data, dtype=data[0].dtype))
            else:
                input_data_list.append(data)

            # ファイル名を追加
            filename_list.append(filename)

            num_problem += 1
        except:
            print(f"入力データ({num_problem})の読み込みに失敗しました。")
            continue

    return num_problem, filename_list, input_data_list, correct_list


def main():
    # データ読み込み
    num_problem, filename_list, input_data_list, correct_list = read_dataset(
        FILEPATH_INPUT_DATA_JSON, ANSWER_VALUE_TYPE, MULTI_DATA, INPUT_DATA_TYPE)

    # ユーザ作成の処理にかける
    answer_list = []
    for i in range(num_problem):
        answer_list.append(recognition(input_data_list[i]))

    # 評価
    abs_errors = []
    for i in range(num_problem):
        abs_errors.append(np.average(np.abs(answer_list[i].astype(int) - correct_list[i].astype(int))))
    print(f"MAE: {np.average(np.array(abs_errors))}")


if __name__ == "__main__":
    main()
